// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/FoldableTheme/widgets/HeaderController/setting/nls/strings":{group:"Nome",openAll:"Abrir todos num painel",dropDown:"Exibir no menu pendente",noGroup:"N\u00e3o est\u00e1 definido qualquer grupo de widgets.",groupSetLabel:"Definir as propriedades de grupos de widgets",_localized:{}}});