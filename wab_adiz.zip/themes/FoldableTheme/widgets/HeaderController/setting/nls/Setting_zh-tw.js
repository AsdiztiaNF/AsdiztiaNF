// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/FoldableTheme/widgets/HeaderController/setting/nls/strings":{group:"\u540d\u7a31",openAll:"\u5728\u4e00\u500b\u9762\u677f\u4e2d\u5168\u90e8\u958b\u555f",dropDown:"\u5728\u4e0b\u62c9\u5f0f\u529f\u80fd\u8868\u4e2d\u986f\u793a",noGroup:"\u4e0d\u5b58\u5728 widget \u7fa4\u7d44\u96c6\u3002",groupSetLabel:"\u8a2d\u5b9a widget \u7fa4\u7d44\u5c6c\u6027",_localized:{}}});