// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/FoldableTheme/widgets/HeaderController/setting/nls/strings":{group:"Nom",openAll:"Obre-ho tot en una subfinestra",dropDown:"Mostra al men\u00fa desplegable",noGroup:"No s'ha definit cap grup de widgets.",groupSetLabel:"Defineix les propietats dels grups de widgets",_localized:{}}});