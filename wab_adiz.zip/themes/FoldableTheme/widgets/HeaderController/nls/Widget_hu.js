// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/FoldableTheme/widgets/HeaderController/nls/strings":{_widgetLabel:"Fejl\u00e9c vez\u00e9rl\u0151",signin:"Bejelentkez\u00e9s",signout:"Kijelentkez\u00e9s",about:"Tov\u00e1bbi inform\u00e1ci\u00f3",signInTo:"Bejelentkez\u00e9s ide:",cantSignOutTip:"Ez a funkci\u00f3 el\u0151n\u00e9zeti m\u00f3dban nem alkalmazhat\u00f3.",more:"t\u00f6bb",_localized:{}}});