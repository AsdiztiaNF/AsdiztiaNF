// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/FoldableTheme/widgets/HeaderController/nls/strings":{_widgetLabel:"\u9801\u9996\u63a7\u5236\u5668",signin:"\u767b\u5165",signout:"\u767b\u51fa",about:"\u95dc\u65bc",signInTo:"\u767b\u5165\u5230",cantSignOutTip:"\u6b64\u529f\u80fd\u4e0d\u9069\u7528\u65bc\u9810\u89bd\u6a21\u5f0f\u3002",more:"\u66f4\u591a",_localized:{}}});